package xna.android;
import android.R.string;
import android.graphics.Bitmap;
import android.graphics.Canvas;


public class Enemy extends SpriteAnimated 
{
	int currentLane; //Int from 0 to 3, indicating the current vertical lane he is at
	
	string currentColor; //Stores the currentColor
	
	boolean alive; //Guess what
	
	Speed speed;
	
	public Enemy(int x, int y, string color, int startLane, Bitmap texture)
	{
		//Hardcoded enemy sizes
		super(texture, x, y, 32, 32, 1, 1);
		this.setX(x);
		this.setY(y);
		
		this.currentColor = color;
		this.currentLane = startLane;
		
		this.setBitmap(texture);
		this.alive = true;
	}
	
	public void Update(long gameTime)
	{
		super.update(gameTime);
	}
	
	public void Draw(Canvas spriteBatch)
	{
		super.draw(spriteBatch);
	}
	
}