package xna.android;

public class GameManager 
{

}
