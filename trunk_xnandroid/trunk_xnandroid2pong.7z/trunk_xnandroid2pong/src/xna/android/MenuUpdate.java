package xna.android;

import android.graphics.Canvas;

public class MenuUpdate 
{
	
	static void Update(long gameTime)
	{
		
	}
	
	static void Draw(Canvas spriteBatch)
	{
		
	}
	
}
