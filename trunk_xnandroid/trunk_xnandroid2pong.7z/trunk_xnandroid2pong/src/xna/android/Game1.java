package xna.android;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import br.com.R;

public class Game1 extends SurfaceView
implements SurfaceHolder.Callback
{
	private static final String TAG = Game1.class.getSimpleName();;

	private MainThread thread;
	
	private SoundManager mSoundManager;
	
	private SpriteFont spriteFont;
	
	private Sprite fundo;
		
	private Player paletaCima, paletaBaixo;
	
	private Sprite bola;
	
	private int screenWidth = 320;
	private int screenHeight = 480;
	/**
	 * 
	 */
	private int eventX, finalX;
		
	private Explosion explosion;
		
	private static final int EXPLOSION_SIZE = 200;
	private Speed bolaSpeed;
	
	//320x480
	
	public Game1(Context Content) {
		super(Content);

		getHolder().addCallback(this);
		bolaSpeed =  new Speed();
		
		mSoundManager = new SoundManager(Content);
		
		fundo =  new Sprite(
				BitmapFactory.decodeResource(getResources(),
				R.drawable.pong_fundo),
				0,
				0,
				mSoundManager);
		
		paletaBaixo = new Player(
				BitmapFactory.decodeResource(getResources(),
				R.drawable.pong_paleta),
				 (screenWidth/2) - 32,
				 screenHeight - 32				
				);
			
		paletaCima = new Player(BitmapFactory.decodeResource(getResources(),
				R.drawable.pong_paleta),
				(screenWidth/2) - 32,
				10
				);
		
		bola = new Sprite(
				BitmapFactory.decodeResource(getResources(),
						R.drawable.pong_bola),
						(screenWidth/2) - 12,
						(screenHeight/2),
						mSoundManager);
		
		bola.setSpeed(bolaSpeed);
		
		spriteFont = new SpriteFont(
				BitmapFactory.decodeResource(getResources(),
						R.drawable.fonte_branca));
		
		thread = new MainThread(getHolder(), this);
		setFocusable(true);
		
	}

	public void surfaceChanged(
			SurfaceHolder holder,
			int format,
			int width,
			int height)
	{
		
		
	}

	public void surfaceCreated(
			SurfaceHolder holder)
	{
		thread.setRunning(true);
		thread.start();
	}

	public void surfaceDestroyed(
			SurfaceHolder holder)
	{
		boolean retry = true;
		
		while (retry)
		{
			try
			{
				thread.join();
				retry = false;
			} catch (
					InterruptedException e)
			{
				
			}
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		
		if (event.getAction() == MotionEvent.ACTION_DOWN)
		{
			// controle de evento com o sprite
			//sprite.handleActionDown((int) event.getX(), (int) event.getY());
			
		}
		if (event.getAction() == MotionEvent.ACTION_MOVE)
		{
			if (event.getX() > paletaBaixo.getX() 
					&& event.getX() < paletaBaixo.getX() + paletaBaixo.getBitmap().getWidth()
					&& event.getY() > paletaBaixo.getY() 
					&& event.getY() < paletaBaixo.getY() + paletaBaixo.getBitmap().getHeight())
				{
					paletaBaixo.setTouched(true);
				}
			eventX = (int) event.getX();
		}
		
		if (event.getAction() == MotionEvent.ACTION_UP)
		{
			finalX = (int) event.getX();
			paletaBaixo.setTouched(false);
//			if (finalX - initX >= 80 )
//			{
//				if(sprite.getX() < 264)
//				{
//				sprite.setCurrentLane(sprite.getCurrentLane()+1);
//				sprite.setX(sprite.getX() + 80);
//				Bullet.CreateBullet(sprite.getCurrentLane(), BitmapFactory.decodeResource(getResources(),
//						R.drawable.red_bullet), sprite.getCurrentLane()*80 + 38, 448);
//				}
//			}
//			if(finalX - initX <= -80)
//			{
//				if(sprite.getX() > 40)
//				{
//				sprite.setCurrentLane(sprite.getCurrentLane()-1);
//				sprite.setX(sprite.getX() - 80);
//				Bullet.CreateBullet(sprite.getCurrentLane(), BitmapFactory.decodeResource(getResources(),
//						R.drawable.red_bullet), sprite.getCurrentLane()*80 + 40, 448);
//
//				}
//			}
		}
		return true;
	}

	@Override
	protected void onDraw(
			Canvas spriteBatch) 
	{
		spriteBatch.drawColor(Color.BLACK);
		
		fundo.draw(spriteBatch);
		
		//TODO fazer poder mudar de cor
		
		paletaBaixo.draw(spriteBatch);
		
		paletaCima.draw(spriteBatch);
		
		bola.draw(spriteBatch);
		
		//spriteBatch.drawBitmap(fundook, 0, 0, Color.BLACK);
		
//		for (int i = 0; i < Bullet.bulletList.size(); i++)
//		{
//			Bullet.bulletList.get(i).Draw(spriteBatch);
//		}
		
		//spriteFont.drawString(spriteBatch, " X i " + initX + " X f " + finalX + " Bullets "+Bullet.bulletList.size(), ((int)getWidth()-350), ((int)getHeight()-100));
		
//		if (explosion != null)
//		{
//			explosion.draw(spriteBatch);
//		}
		
//		for (int i = 0; i < Button.buttonList.size(); i++)
//		{
//			Button.buttonList.get(i).draw(spriteBatch);
//		}
		
//		border.setX(Button.buttonList.get(Button.selectedButton).getX());
//		border.setY(Button.buttonList.get(Button.selectedButton).getY());
//		border.draw(spriteBatch);
//		
//		sprite.draw(spriteBatch);
			
		//bullet_teste.Draw(spriteBatch);
	}

	public void Update()
	{
		bola.update(screenWidth, screenHeight);
		//int paletaCimaX = paletaCima.getX() + paletaCima;
		
		if ( paletaBaixo.isTouched())
		{
			paletaBaixo.setX(eventX);
		}
		
//		for (int i = 0; i < Bullet.bulletList.size(); i++)
//		{
//			Bullet.bulletList.get(i).Update();
//		}
//		
//		if (explosion != null && explosion.isAlive())
//		{
//			explosion.update(getHolder().getSurfaceFrame());
//		}
		
	}
	
	public void Draw(Canvas canvas)
	{
		onDraw(canvas);
	}
}