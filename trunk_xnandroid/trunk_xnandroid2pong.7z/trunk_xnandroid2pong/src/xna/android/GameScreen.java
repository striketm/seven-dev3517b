package xna.android;

public final class GameScreen 
{
	
	public static void Update()
	{
		
	}
	
	public static void Initialize()
	{
		
	}
	
	public static void LoadContent()
	{
		
	}
	
	public static void Draw()
	{
		
	}
	
	
}
