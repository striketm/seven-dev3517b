﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using game.util;
using game.util.character;
using game.util.scene;

namespace ProjetoFinalXNA_Megaman
{
    class TelaFase1
    {

        Image cena1, cena2;
        Scene scene;

        Character megamanx;

        Image chao;

        KeyboardState oldTeclado;

        public TelaFase1(ContentManager content)
        {
            cena1 = new Image(content, "cena1", 0, 0, 800, 480);
            cena2 = new Image(content, "cena2", 800, 0, 800, 480);
            scene = new Scene();
            scene.Add(cena1);
            scene.Add(cena2);
            megamanx = new Character(content, 350, 10, 82, 98);
            
            megamanx.AddNewSpriteIdle("megamanx_parado_1");
            megamanx.AddNewSpriteIdle("megamanx_parado_1");
            megamanx.AddNewSpriteIdle("megamanx_parado_1");
            megamanx.AddNewSpriteIdle("megamanx_parado_1");
            megamanx.AddNewSpriteIdle("megamanx_parado_2");
            megamanx.AddNewSpriteIdle("megamanx_parado_3");

            megamanx.AddNewSpriteRunning("megamanx_correndo_1");
            megamanx.AddNewSpriteRunning("megamanx_correndo_2");
            megamanx.AddNewSpriteRunning("megamanx_correndo_3");
            megamanx.AddNewSpriteRunning("megamanx_correndo_4");
            megamanx.AddNewSpriteRunning("megamanx_correndo_5");
            megamanx.AddNewSpriteRunning("megamanx_correndo_6");
            megamanx.AddNewSpriteRunning("megamanx_correndo_7");
            megamanx.AddNewSpriteRunning("megamanx_correndo_8");
            megamanx.AddNewSpriteRunning("megamanx_correndo_9");

            megamanx.AddNewSpriteJumping("megamanx_pulando_1");
            megamanx.AddNewSpriteJumping("megamanx_pulando_2");
            megamanx.AddNewSpriteJumping("megamanx_pulando_3");

            megamanx.Idle(10, true);

            megamanx.AddCollisionElementOfFallByTag("chao");

            scene.Add(megamanx);

            chao = new Image(content, "chao", 0, 480 - 100, 800, 100);
            scene.Add(chao);
            chao.SetTag("chao");
        }

        public void Update(GameTime gameTime, KeyboardState teclado)
        {
            if ((teclado.IsKeyDown(Keys.Space)) && 
               (!(oldTeclado.IsKeyDown(Keys.Space))))
                megamanx.Jump(7, false);

            if (teclado.IsKeyDown(Keys.Right))
            {
                megamanx.RunningToRight(7, true);

                cena1.MoveByX(-8);
                cena2.MoveByX(-8);

                if (cena1.GetX() < -cena1.GetWidth())
                    cena1.SetX(cena2.GetX() + cena2.GetWidth());

                if (cena2.GetX() < -cena2.GetWidth())
                    cena2.SetX(cena1.GetX() + cena1.GetWidth());

            }
            else if (teclado.IsKeyDown(Keys.Left))
            {
                megamanx.RunningToLeft(7, true);

                cena1.MoveByX(8);
                cena2.MoveByX(8);

                if (cena1.GetX() > 800)
                    cena1.SetX(cena2.GetX() - cena2.GetWidth());

                if (cena2.GetX() > 800)
                    cena2.SetX(cena1.GetX() - cena1.GetWidth());

            }
            else
            {
                megamanx.Idle(10, true);
            }

            megamanx.Update(scene);

            oldTeclado = teclado;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            scene.Draw(spriteBatch);

        }


    }
}

