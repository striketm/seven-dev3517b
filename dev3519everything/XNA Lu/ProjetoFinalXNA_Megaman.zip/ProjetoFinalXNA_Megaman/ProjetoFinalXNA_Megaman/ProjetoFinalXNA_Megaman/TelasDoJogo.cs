﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjetoFinalXNA_Megaman
{
    class TelasDoJogo
    {
        public enum TelaJogo { TELA_ABERTURA, TELA_FASE1 }

        public static TelaJogo tela;

    }
}
