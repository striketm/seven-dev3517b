﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using game.util;
using game.util.character;
using game.util.scene;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace ProjetoFinalXNA_Megaman
{
    class Inimigo1 : GameElement
    {
        AnimationSprites inimigo;

        int contaFrame = 0;

        enum Sentido { DIREITA, ESQUERDA }

        Sentido sentidoInimigo = Sentido.DIREITA;

        public Inimigo1(ContentManager content, int x, int y, int w, int h)
        {
            inimigo = new AnimationSprites(content, x, y, w, h);

            inimigo.Add("inimigo_1_1");
            inimigo.Add("inimigo_1_2");
            inimigo.Add("inimigo_1_3");
            inimigo.Add("inimigo_1_4");
            inimigo.Add("inimigo_1_5");

            SetBounds(x, y, w, h);

            inimigo.Start(4, true);
        }

        public void MoveByX(int value)
        {
            base.MoveByX(value);
            inimigo.MoveByX(value);

        }

        public void MoveByY(int value)
        {
            base.MoveByY(value);
            inimigo.MoveByY(value);

        }


        public override void Draw(SpriteBatch spriteBatch)
        {
            inimigo.Draw(spriteBatch);
        }

        public void Update(Scene scene)
        {
            contaFrame++;

            if (contaFrame == 20)
            {
                contaFrame = 0;
                if (sentidoInimigo == Sentido.DIREITA)
                    sentidoInimigo = Sentido.ESQUERDA;
                else
                    sentidoInimigo = Sentido.DIREITA;
            }

            if (sentidoInimigo == Sentido.DIREITA)
                MoveByX(6);
            else
                MoveByX(-6);
        }

    }
}
