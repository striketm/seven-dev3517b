﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using game.util;
using game.util.character;
using game.util.scene;

namespace ProjetoFinalXNA_Megaman
{
    class TelaFase1
    {

        Image cena1, cena2;
        Scene scene;

        Character megamanx;

        Image chao;

        KeyboardState oldTeclado;

        int contaPasso = 0;

        enum Sentido { DIREITA, ESQUERDA }

        Sentido sentidoMegaman;

        ContentManager content;

        public TelaFase1(ContentManager content)
        {

            this.content = content;
            sentidoMegaman = Sentido.DIREITA;

            cena1 = new Image(content, "cena1", 0, 0, 800, 480);
            cena2 = new Image(content, "cena2", 800, 0, 800, 480);
            scene = new Scene();
            scene.Add(cena1);
            scene.Add(cena2);
            megamanx = new Character(content, 350, 10, 82, 98);
            
            megamanx.AddNewSpriteIdle("megamanx_parado_1");
            megamanx.AddNewSpriteIdle("megamanx_parado_1");
            megamanx.AddNewSpriteIdle("megamanx_parado_1");
            megamanx.AddNewSpriteIdle("megamanx_parado_1");
            megamanx.AddNewSpriteIdle("megamanx_parado_2");
            megamanx.AddNewSpriteIdle("megamanx_parado_3");

            megamanx.AddNewSpriteRunning("megamanx_correndo_1");
            megamanx.AddNewSpriteRunning("megamanx_correndo_2");
            megamanx.AddNewSpriteRunning("megamanx_correndo_3");
            megamanx.AddNewSpriteRunning("megamanx_correndo_4");
            megamanx.AddNewSpriteRunning("megamanx_correndo_5");
            megamanx.AddNewSpriteRunning("megamanx_correndo_6");
            megamanx.AddNewSpriteRunning("megamanx_correndo_7");
            megamanx.AddNewSpriteRunning("megamanx_correndo_8");
            megamanx.AddNewSpriteRunning("megamanx_correndo_9");

            megamanx.AddNewSpriteJumping("megamanx_pulando_1");
            megamanx.AddNewSpriteJumping("megamanx_pulando_2");
            megamanx.AddNewSpriteJumping("megamanx_pulando_3");

            megamanx.AddNewSpriteAttack1("megamanx_atirando");

            megamanx.Idle(10, true);

            megamanx.AddCollisionElementOfFallByTag("chao");

            scene.Add(megamanx);

            chao = new Image(content, "chao", 0, 480 - 100, 800, 100);
            scene.Add(chao);
            chao.SetTag("chao");

            scene.Add(new Inimigo1(content, 500, 300, 80, 73));

            scene.Add(new Inimigo1(content, 1500, 300, 80, 73));

            scene.Add(new Inimigo1(content, 2500, 300, 80, 73));
        }

        public void Update(GameTime gameTime, KeyboardState teclado)
        {
            if ((teclado.IsKeyDown(Keys.Space)) && 
               (!(oldTeclado.IsKeyDown(Keys.Space))))
                megamanx.Jump(7, false);

            if ((teclado.IsKeyDown(Keys.LeftControl)) &&
               (!(oldTeclado.IsKeyDown(Keys.LeftControl))))
            {
                Image tiro;

                if (sentidoMegaman == Sentido.DIREITA)
                {
                    tiro = new Image(content, "tiro_megamanx",
                    megamanx.GetX() + megamanx.GetWidth(),
                    megamanx.GetY() + 50, 16, 16);
                    tiro.SetTag("tiro_direita");

                }
                else
                {
                    tiro = new Image(content, "tiro_megamanx",
                    megamanx.GetX() - 16,
                    megamanx.GetY() + 50, 16, 16);
                    tiro.SetTag("tiro_esquerda");

                }

                scene.Add(tiro);

                megamanx.Attack1(10);
            }


            if (teclado.IsKeyDown(Keys.Right))
            {
                sentidoMegaman = Sentido.DIREITA;

                megamanx.RunningToRight(7, true);

                contaPasso++;

                if (contaPasso > 0)
                {

                    cena1.MoveByX(-8);
                    cena2.MoveByX(-8);

                    if (cena1.GetX() < -cena1.GetWidth())
                        cena1.SetX(cena2.GetX() + cena2.GetWidth());

                    if (cena2.GetX() < -cena2.GetWidth())
                        cena2.SetX(cena1.GetX() + cena1.GetWidth());


                    foreach (GameElement e in scene.Elements())
                    {
                        if (e is Inimigo1)
                        {
                            ((Inimigo1)e).MoveByX(-8);
                        }
                    }
                }
                else
                {
                    megamanx.MoveByX(8);
                }

            }
            else if (teclado.IsKeyDown(Keys.Left))
            {

                sentidoMegaman = Sentido.ESQUERDA;

                megamanx.RunningToLeft(7, true);

                contaPasso--;


                if (contaPasso > 0)
                {

                    cena1.MoveByX(8);
                    cena2.MoveByX(8);

                    if (cena1.GetX() > 800)
                        cena1.SetX(cena2.GetX() - cena2.GetWidth());

                    if (cena2.GetX() > 800)
                        cena2.SetX(cena1.GetX() - cena1.GetWidth());

                    foreach (GameElement e in scene.Elements())
                    {
                        if (e is Inimigo1)
                        {
                            ((Inimigo1)e).MoveByX(8);
                        }
                    }
                }
                else
                {
                    megamanx.MoveByX(-8);
                }

            }
            else
            {
                if(!megamanx.IsAttacking())
                  megamanx.Idle(10, true);
            }

            megamanx.Update(scene);

            foreach (GameElement e in scene.Elements())
            {
                if (e is Inimigo1)
                    ((Inimigo1)e).Update(scene);
            }


            foreach (GameElement e in scene.Elements())
            {
                if (e.GetTag() == "tiro_direita")
                {
                    e.MoveByX(15);

                    if (e.GetX() > 800)
                    {
                        scene.Remove(e);
                        break;
                    }

                    bool atingiuInimigo = false;

                    foreach(GameElement i in scene.Elements())
                    {
                        if (i is Inimigo1)
                        {
                            if (Collision.Check(e, i))
                            {
                                scene.Remove(i);
                                atingiuInimigo = true;
                                break;
                            }
                        }
                    }

                    if (atingiuInimigo)
                    {
                        scene.Remove(e);
                        break;
                    }



                }
                else if (e.GetTag() == "tiro_esquerda")
                {
                    e.MoveByX(-15);

                    if (e.GetX() < -e.GetWidth())
                    {
                        scene.Remove(e);
                        break;
                    }

                    bool atingiuInimigo = false;

                    foreach (GameElement i in scene.Elements())
                    {
                        if (i is Inimigo1)
                        {
                            if (Collision.Check(e, i))
                            {
                                scene.Remove(i);
                                atingiuInimigo = true;
                                break;
                            }
                        }
                    }

                    if (atingiuInimigo)
                    {
                        scene.Remove(e);
                        break;
                    }
                }



            }


            oldTeclado = teclado;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            scene.Draw(spriteBatch);

        }


    }
}


