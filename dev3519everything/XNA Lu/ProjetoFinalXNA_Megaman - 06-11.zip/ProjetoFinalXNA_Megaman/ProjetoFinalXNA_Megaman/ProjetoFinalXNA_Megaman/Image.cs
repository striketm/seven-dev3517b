﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace game.util
{
    class Image : GameElement
    {
        Texture2D image, image_flipped;

        public Image(ContentManager content, String path, int x, int y, int w, int h) {

            image = content.Load<Texture2D>(path);

            image_flipped = FlipHorizontal(image);

            SetBounds(x, y, w, h);

        }


        public override void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(image, new Rectangle(x, y, width, height), Color.White);
        }



        public void Draw(SpriteBatch spriteBatch, bool flip_horizontal)
        {
            if (flip_horizontal)
                spriteBatch.Draw(image_flipped, new Rectangle(x, y, width, height), Color.White);
            else
                spriteBatch.Draw(image, new Rectangle(x, y, width, height), Color.White);
        }

        
        private static Texture2D FlipHorizontal(Texture2D source)
        {
            Texture2D flipped = new Texture2D(source.GraphicsDevice, source.Width, source.Height);
            Color[] data = new Color[source.Width * source.Height];
            Color[] flippedData = new Color[data.Length];

            source.GetData<Color>(data);

            for (int x = 0; x < source.Width; x++)
                for (int y = 0; y < source.Height; y++)
                {
                    int idx = (source.Width - 1 - x) + ((y) * source.Width);
                    flippedData[x + y * source.Width] = data[idx];
                }

            flipped.SetData<Color>(flippedData);

            return flipped;
        }

    }

}
