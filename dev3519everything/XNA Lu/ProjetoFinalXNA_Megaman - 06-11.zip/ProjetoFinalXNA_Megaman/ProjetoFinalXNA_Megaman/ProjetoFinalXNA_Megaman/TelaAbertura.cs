﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using game.util;


namespace ProjetoFinalXNA_Megaman
{
    class TelaAbertura
    {

        Image tela_abertura_megaman;

        SpriteFont fonte;

        public TelaAbertura(ContentManager content)
        {
            tela_abertura_megaman = new Image(content, "tela_abertura_megaman", 0, 0, 800, 480);
            fonte = content.Load<SpriteFont>("minhafonte");
        }

        public void Update(GameTime gameTime, KeyboardState teclado)
        {

        }

        public void Draw(SpriteBatch spriteBatch)
        {
            tela_abertura_megaman.Draw(spriteBatch);
            spriteBatch.DrawString(fonte, "Pressione ENTER para começar", new Vector2(400, 250),
            Color.White);
        }
    }
}
