﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace game.util
{
    abstract class GameElement
    {
        protected int x;

        protected int y;

        protected int width;

        protected int height;

        protected string tag;


        public void SetX(int x)
        {
            this.x = x;

        }

        public void SetY(int y)
        {
            this.y = y;

        }

        public void SetWidth(int width)
        {
            this.width = width;

        }

        public void SetHeight(int height)
        {
            this.height = height;

        }

        public void MoveByX(int x)
        {

            this.x += x;

        }

        public void MoveByY(int y)
        {

            this.y += y;

        }


        public void SetBounds(int x, int y, int width, int height)
        {
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;

        }

        public void SetTag(String tag)
        {
            this.tag = tag;
        }

        public int GetX() { return x; }

        public int GetY() { return y; }

        public int GetWidth() { return width; }

        public int GetHeight() { return height; }

        public string GetTag() { return tag; }

        public virtual void Draw(SpriteBatch spriteBatch) { }

        public bool IsClicked(int posx, int posy)
        {

            if ((posx >= x) && (posx <= x + width)
            && (posy >= y) && (posy <= y + height))
                return true;
            else
                return false;
        }


      
    
    }
}
