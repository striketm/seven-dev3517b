package br.com.supermegabros;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;

public class Bloco extends ImageView {

	public Bloco(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

}
