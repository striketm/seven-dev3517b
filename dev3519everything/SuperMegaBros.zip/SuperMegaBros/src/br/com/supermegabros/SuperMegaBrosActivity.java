package br.com.supermegabros;

import game.util.GameObject;
import android.app.Activity;
import android.os.Bundle;
import android.text.style.UpdateLayout;
import android.view.*;
import android.widget.*;
import android.os.*;

public class SuperMegaBrosActivity extends Activity {
    /** Called when the activity is first created. */
	
	Megaman megaman;
	
	enum Sentido {DIREITA, ESQUERDA, PARADO}
	Sentido sentido;
	
	Handler update;
	
	Runnable rUpdate;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        megaman = (Megaman) findViewById(R.id.megaman);
        sentido = Sentido.PARADO;
        update = new Handler();
        
        rUpdate = new Runnable() {
			
			@Override
			public void run() {
				
				if(sentido == Sentido.DIREITA)
					GameObject.MoveByX(megaman, 10);
				else if (sentido == Sentido.ESQUERDA)
					GameObject.MoveByX(megaman, -10);
					
				update.postDelayed(rUpdate, 10);
			}
		};
		
		update.removeCallbacks(rUpdate);
		update.postDelayed(rUpdate, 100);
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
    	// TODO Auto-generated method stub
    	if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
    		
    		if(sentido != Sentido.DIREITA) {
    		
    			sentido = Sentido.DIREITA;
    			megaman.MoverParaDireita();
    		
    		}
    		
    	}
    	else if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
    	
    		
    		if(sentido != Sentido.ESQUERDA) {
        		
    			sentido = Sentido.ESQUERDA;
    			megaman.MoverParaEsquerda();
    		
    		}
    		
    		
    	}
    	return super.onKeyDown(keyCode, event);
    }
    
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
    	// TODO Auto-generated method stub
    	
    	if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
    		sentido = Sentido.PARADO;
    		megaman.Parar();
    	} else if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
    		sentido = Sentido.PARADO;
    		megaman.Parar();
    	}
    	
    	return super.onKeyUp(keyCode, event);
    }
}