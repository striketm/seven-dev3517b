package br.com.supermegabros;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.util.AttributeSet;
import android.widget.ImageView;

public class Megaman extends ImageView {
	
	enum Status {PARADO, CORRENDO};
	Status sts;
	
	enum Sentido {DIREITA, ESQUERDA};
	Sentido sentido;
	
	AnimationDrawable animation;

	public Megaman(Context context, AttributeSet attrs) {
		super(context, attrs);
		
		sts = Status.PARADO;
		sentido = Sentido.DIREITA;
		
	}
	
	
	public void MoverParaDireita() {
		
		
		sts = Status.CORRENDO;
		
		if(sentido != Sentido.DIREITA) {
			
			sentido = Sentido.DIREITA;
			
			
			
		}
		
		setImageResource(R.drawable.megaman_correndo_direita);
		animation = (AnimationDrawable) getDrawable();
		
		animation.start();
		
	}
	
	
   public void MoverParaEsquerda() {
	   
	   sts = Status.CORRENDO;
		
		if(sentido != Sentido.ESQUERDA) {
			
			sentido = Sentido.ESQUERDA;
			
			
			
		}
		
		setImageResource(R.drawable.megaman_correndo_esquerda);
		animation = (AnimationDrawable) getDrawable();
		
		animation.start();
		
	}
   
   
   public void Parar() {
	   
	   sts = Status.PARADO;
	   
	   if(sentido == Sentido.DIREITA )
	   {
		  
		   setImageResource(R.drawable.megaman_parado_direita);
	   } else {
		   
		   
		   setImageResource(R.drawable.megaman_parado_esquerda);
	   }
	   
	   
   }
   
   
   
   
   
   
   
   
   

}
