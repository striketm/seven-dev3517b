package br.com.supermegabros;

import game.util.GameObject;
import android.app.Activity;
import android.os.Bundle;
import android.text.style.UpdateLayout;
import android.view.*;
import android.widget.*;
import android.os.*;

public class SuperMegaBrosActivity extends Activity {
    /** Called when the activity is first created. */
	
	Megaman megaman;
	AbsoluteLayout tela;
	
	enum Sentido {DIREITA, ESQUERDA, PARADO}
	Sentido sentido;
	
	Handler update;
	
	Runnable rUpdate;
	
	
	boolean pulou;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        megaman = (Megaman) findViewById(R.id.megaman);
        tela = (AbsoluteLayout) findViewById(R.id.tela);
        update = new Handler();
        sentido = Sentido.PARADO;
        
        pulou = false;
        
        
        
        rUpdate = new Runnable() {
			
			public void run() {
				
				megaman.Processar(tela);
				
				if(sentido == Sentido.DIREITA)
					GameObject.MoveByX(megaman, 10);
				else if (sentido == Sentido.ESQUERDA)
					GameObject.MoveByX(megaman, -10);
					
				update.postDelayed(rUpdate, 10);
				
				
				if(pulou) {
					pulou = false;
					megaman.Pular();
				}
			}
		};
		
		update.removeCallbacks(rUpdate);
		update.postDelayed(rUpdate, 100);
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
    	// TODO Auto-generated method stub
    	if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
    	{
    		if(sentido != Sentido.DIREITA) {
    			sentido = Sentido.DIREITA;
    			megaman.MoverParaDireita();
    		}
    	} else if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT)
    	{
    		if(sentido != Sentido.ESQUERDA) {
    			sentido = Sentido.ESQUERDA;
    			megaman.MoverParaEsquerda();
    		}
    	}
    	else if(keyCode == KeyEvent.KEYCODE_DPAD_UP) {
    		
    		if(!pulou)
    			pulou=true;
    	}
    	
    	
    	return super.onKeyDown(keyCode, event);
    }
    
    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
    	// TODO Auto-generated method stub
    	if(keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
    			sentido = Sentido.PARADO;
    			megaman.Parar();
    		
    	} if(keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
			sentido = Sentido.PARADO;
			megaman.Parar();
		
	} else if(keyCode == KeyEvent.KEYCODE_DPAD_UP) {
		
		pulou=false;
	}
    	return super.onKeyUp(keyCode, event);
    };
}