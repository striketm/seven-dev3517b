using System;

namespace Microsoft.Xna.Framework.Net
{
	public enum CommandEventType
	{
		GamerJoined,
		GamerLeft,
		SessionStateChange,
		SendData,
		ReceiveData,
		GamerStateChange,
	}
}

