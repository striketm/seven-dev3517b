using System;

namespace MonoGame.Framework
{
	public class TitleContainer
	{
		public TitleContainer ()
		{
		}
	}
}

