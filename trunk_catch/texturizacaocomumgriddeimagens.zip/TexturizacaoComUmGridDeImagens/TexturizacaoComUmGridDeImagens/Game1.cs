using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace TexturizacaoComUmGridDeImagens
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;

        /// <summary>
        /// Shader provido pelo XNA.
        /// Reponsavel por renderizar as primitivas
        /// </summary>
        BasicEffect basicEffect;

        Texture2D texture;

        /// <summary>
        /// A posicao do passarinho vermelho na tela
        /// </summary>
        Vector2 posicao1;

        /// <summary>
        /// A posicao do passarinho verde na tela
        /// </summary>
        Vector2 posicao2;

        /// <summary>
        /// Os campos (X,Y) do retangulo v�o determinar a origem do local 
        /// aonde o retangulo ser� definido na textura.
        /// </summary>
        Rectangle rectangle1;

        /// <summary>
        /// Os campos (X,Y) do retangulo v�o determinar a origem do local 
        /// aonde o retangulo ser� definido na textura.
        /// </summary>
        Rectangle rectangle2;

        /*Um objeto VertexDeclaration armazena o formato do v�rtice para o 
         * dado contido em cada em cada v�rtice da figura ou modelo. 
         * Antes de desenhar o objeto, o GraphicsDevice precisa ser 
         * modificado para usar o formato correto para permitir a 
         * recupera��o apropriada do dado do v�rtice de cada v�rtice do array.
         * */
        /// <summary>
        /// Armazena o formato do vertice, neste exemplo guardara o formato
        /// do vertice de tipo VertexPositionColor
        /// </summary>
        VertexDeclaration vertexDeclaration;

        /// <summary>
        /// Nesta demonstra��o, ser� o array responsavel 
        /// por representar o passarinho vermelho
        /// </summary>
        VertexPositionTexture[] triangleFan1;

        /// <summary>
        /// Nesta demonstra��o, ser� o array responsavel 
        /// por representar o passarinho verde
        /// </summary>
        VertexPositionTexture[] triangleFan2;


        /// <summary>
        /// Define um objeto retangular para o array de vertices PartialTextureTriangleFan
        /// </summary>
        /// <param name="posicao">Posicao em que a imagem ser� desenhada na janela(Game Window)</param>
        /// <param name="rectangle">Um retangulo que sera definido dentro da textura; sera
        /// este local retangular que ser� renderizado</param>
        /// <param name="triangleFan">Array de vertices</param>
        void define_Rectangular_Object(Vector2 posicao,            
            Rectangle rectangle,
            ref VertexPositionTexture[] triangleFan)
        {
            triangleFan = new VertexPositionTexture[4];            
            
            float originWidthProportion = rectangle.X / (float)this.texture.Width;
            float originHeightProportion = rectangle.Y / (float)this.texture.Height;

            float Widthproportion = rectangle.Width / (float)this.texture.Width;
            float Heightproportion = rectangle.Height / (float)this.texture.Height;

            triangleFan[0].Position.X = posicao.X;
            triangleFan[0].Position.Y = posicao.Y;
            triangleFan[0].TextureCoordinate 
                = new Vector2(originWidthProportion, originHeightProportion);

            triangleFan[1].Position.X = posicao.X + rectangle.Width;
            triangleFan[1].Position.Y = posicao.Y;
            triangleFan[1].TextureCoordinate =
                new Vector2(Widthproportion + originWidthProportion, originHeightProportion);

            triangleFan[2].Position.X = posicao.X + rectangle.Width;
            triangleFan[2].Position.Y = posicao.Y + rectangle.Height;
            triangleFan[2].TextureCoordinate =
                new Vector2(Widthproportion + originWidthProportion, Heightproportion + originHeightProportion);

            triangleFan[3].Position.X = posicao.X;
            triangleFan[3].Position.Y = posicao.Y + rectangle.Height;
            triangleFan[3].TextureCoordinate =
                new Vector2(originWidthProportion, Heightproportion + originHeightProportion);
        }


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {

            // posicao do passarinho vermelho na tela
            this.posicao1 = Vector2.Zero;

            //Nesta demonstra��o, a posicao(X e Y) e 
            //dimens�es(Width e Height) escolhidas servir�o para
            // mostrar o passarinho vermelho
            this.rectangle1 = new Rectangle(275, 0, 140, 90);

            // posicao do passarinho verde na tela
            this.posicao2 = new Vector2(200, 200);

            //Nesta demonstra��o, a posicao(X e Y) e 
            //dimens�es(Width e Height) escolhidas servir�o para
            // mostrar o passarinho verde
            this.rectangle2 = new Rectangle(275, 90, 140, 75);

            base.Initialize();           
        }

        protected override void LoadContent()
        {
            this.texture = this.Content.Load<Texture2D>("imagens");

            this.define_Rectangular_Object(this.posicao1,
                this.rectangle1, ref this.triangleFan1);

            this.define_Rectangular_Object(this.posicao2,
                this.rectangle2, ref this.triangleFan2);

            this.basicEffect = new BasicEffect(this.GraphicsDevice, null);

            this.vertexDeclaration = new VertexDeclaration(
                this.GraphicsDevice, VertexPositionTexture.VertexElements);

            /*Mudando a Origem da tela; O local aonde os eixos se cruzam.
             * No XNA, por padr�o, a origem est� no meio da janela. Com o codigo abaixo,
             * a origem ficar� no canto superior esquerdo da tela da janela; 
             * o padrao usado no ambiente 2D
             * */
            this.basicEffect.Projection
            = Matrix.CreateOrthographicOffCenter(
                    0, this.GraphicsDevice.Viewport.Width,
                    this.GraphicsDevice.Viewport.Height, 0, 0, 50);
                        
            //permiti que texturas sejam aplicadas
            this.basicEffect.TextureEnabled = true;

            /*� toda primitiva renderizada por este efeito, 
             * ser� atribuida esta textura*/
            this.basicEffect.Texture = texture;

            base.LoadContent();
        }
        
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.CornflowerBlue);

            this.GraphicsDevice.VertexDeclaration = this.vertexDeclaration;            

            this.basicEffect.Begin();
            
            foreach (EffectPass pass in basicEffect.CurrentTechnique.Passes)
            {
                pass.Begin();

                this.GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleFan,
                    triangleFan1, 0, 2);

                this.GraphicsDevice.DrawUserPrimitives(PrimitiveType.TriangleFan,
                    triangleFan2, 0, 2);

                pass.End();
            }

            this.basicEffect.End();

            base.Draw(gameTime);
        }
    }
}
