using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;
using Snake.Core;

namespace Snake
{
    /// <summary>
    /// This is a game component that implements the Action Scene.
    /// </summary>
    public class ActionScene : GameScene
    {
        // Basics
        protected Texture2D actionTexture;
        protected SpriteBatch spriteBatch = null;
        
        // Game Elements
        protected Snake snake1;
        protected Snake snake2;
        protected Food egg;
        protected Food fish;
        protected ImageComponent background;
        protected Score scoreSnake1;
        protected Score scoreSnake2;

        // Constants and counters
        protected const int BONUSTIMEON = 5000;
        protected const int BONUSCOUNTDELAY = 10;
        protected int currentFoodCounter;
        protected int lastTickCount;

        // Gui Stuff
        protected Vector2 pausePosition;
        protected Vector2 gameoverPosition;
        protected Rectangle pauseRect = new Rectangle(3, 117, 150, 47);
        protected Rectangle gameoverRect = new Rectangle(4, 166, 295, 52);

        // GameState elements
        protected bool paused;
        protected bool gameOver;
        protected TimeSpan elapsedTime = TimeSpan.Zero;
        protected bool twoPlayers;

        /// <summary>
        /// Default Constructor
        /// </summary>
        /// <param name="game">The main game object</param>
        /// <param name="theTexture">Texture with the sprite elements</param>
        /// <param name="backgroundTexture">Texture for the background</param>
        /// <param name="font">Font used in the score</param>
        public ActionScene(Game game, Texture2D theTexture,
            Texture2D backgroundTexture, SpriteFont font)
            : base(game)
        {            
            background = new ImageComponent(game, backgroundTexture, 
                ImageComponent.DrawMode.Stretch);
            Components.Add(background);

            actionTexture = theTexture;

            // Get the current sprite batch
            spriteBatch = (SpriteBatch)
                Game.Services.GetService(typeof(SpriteBatch));

            egg = new Food(game, ref actionTexture, new Rectangle(122, 43, 10, 10), 10);
            Components.Add(egg);
            fish = new Food(game, ref actionTexture, new Rectangle(101, 43, 10, 10), 25);
            Components.Add(fish);

            snake1 = new Snake(game, ref actionTexture, PlayerIndex.One, new Rectangle(56, 43, 10, 10));
            Components.Add(snake1);
            snake2 = new Snake(game, ref actionTexture, PlayerIndex.Two, new Rectangle(45, 43, 10, 10));
            Components.Add(snake2);

            scoreSnake1 = new Score(game, font, Color.Blue);
            scoreSnake1.Position = new Vector2(5, 5);
            Components.Add(scoreSnake1);
            scoreSnake2 = new Score(game, font, Color.Red);
            scoreSnake2.Position = new Vector2(5, 5 + font.LineSpacing);
            Components.Add(scoreSnake2);
        }
        
        /// <summary>
        /// Show the action scene
        /// </summary>
        public override void Show()
        {
            snake1.PutinStartPosition();
            scoreSnake1.Value = 0;
            snake2.PutinStartPosition();
            scoreSnake2.Value = 0;

            do
                egg.PutinNewPosition();
            while (snake1.CheckCollision(egg.position) || snake2.CheckCollision(egg.position));
            fish.Unvisible();

            paused = false;
            pausePosition.X = (Game.Window.ClientBounds.Width -
                pauseRect.Width) / 2;
            pausePosition.Y = (Game.Window.ClientBounds.Height -
                pauseRect.Height) / 2;

            gameOver = false;
            gameoverPosition.X = (Game.Window.ClientBounds.Width -
                gameoverRect.Width) / 2;
            gameoverPosition.Y = (Game.Window.ClientBounds.Height -
                gameoverRect.Height) / 2;

            // Is a two-player game?
            snake1.Visible = true;
            snake2.Visible = twoPlayers;
            snake2.Enabled = twoPlayers;
            scoreSnake2.Visible = twoPlayers;
            scoreSnake2.Enabled = twoPlayers;

            // Timer and counter for bonus fish
            lastTickCount = Environment.TickCount;
            currentFoodCounter = 0;

            base.Show();
        }

        /// <summary>
        /// Hide the scene
        /// </summary>
        public override void Hide()
        {
            // Stop the background music
            MediaPlayer.Stop();
            MediaPlayer.Volume = 1.0f;

            base.Hide();
        }

        /// <summary>
        /// Indicate the 2-players game mode
        /// </summary>
        public bool TwoPlayers
        {
            get { return twoPlayers; }
            set { twoPlayers = value; }
        }

        /// <summary>
        /// True, if the game is in GameOver state
        /// </summary>
        public bool GameOver
        {
            get { return gameOver; }
        }

        /// <summary>
        /// Paused mode
        /// </summary>
        public bool Paused
        {
            get { return paused; }
            set
            {
                paused = value;
                if (paused)
                {
                    MediaPlayer.Pause();
                }
                else
                {
                    MediaPlayer.Resume();
                }
            }
        }

        /// <summary>
        /// Allows the game component to update itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Update(GameTime gameTime)
        {
            if ((!paused) && (!gameOver))
            {
                // Place bonus food on game field
                if (currentFoodCounter == BONUSCOUNTDELAY)
                {
                    currentFoodCounter = 0;
                    
                    lastTickCount = Environment.TickCount;
                    
                    do
                        fish.PutinNewPosition();
                    while (snake1.CheckCollision(fish.position) ||
                        snake2.CheckCollision(fish.position) || 
                        (egg.position == fish.position));
                }
                // Remove bonus food
                if ((Environment.TickCount - lastTickCount) >= BONUSTIMEON)
                    fish.Unvisible();

                // Check collisions with food for player 1
                if (snake1.Head == egg.position)
                {
                    snake1.lunch = true;

                    do
                        egg.PutinNewPosition();
                    while (snake1.CheckCollision(egg.position) ||
                        snake2.CheckCollision(egg.position));

                    scoreSnake1.Value += egg.cost;

                    currentFoodCounter++;
                }
                else if (snake1.Head == fish.position)
                {
                    snake1.lunch = true;
                    scoreSnake1.Value += fish.cost;
                    fish.Unvisible();
                }
                else
                    snake1.lunch = false;
                // Check collisions with food for player 2
                if (TwoPlayers)
                {
                    if (snake2.Head == egg.position)
                    {
                        snake2.lunch = true;

                        do
                            egg.PutinNewPosition();
                        while (snake2.CheckCollision(egg.position) ||
                            snake2.CheckCollision(egg.position));

                        scoreSnake2.Value += egg.cost;

                        currentFoodCounter++;
                    }
                    else if (snake2.Head == fish.position)
                    {
                        snake2.lunch = true;
                        scoreSnake2.Value += fish.cost;
                        fish.Unvisible();
                    }
                    else
                        snake2.lunch = false;
                }

                // Check itself collision
                gameOver = snake1.CheckCollision(snake1.Head) ||
                    snake2.CheckCollision(snake2.Head);
                if (!gameOver)
                {
                    // Update all other game components
                    base.Update(gameTime);
                }
            }
        }

        /// <summary>
        /// Allows the game component to draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        public override void Draw(GameTime gameTime)
        {
            // Draw all game components
            base.Draw(gameTime);

            if (paused)
            {
                // Draw the "pause" text
                spriteBatch.Draw(actionTexture, pausePosition, pauseRect,
                    Color.White);
            }
            if (gameOver)
            {
                // Draw the "gameover" text
                spriteBatch.Draw(actionTexture, gameoverPosition, gameoverRect,
                    Color.White);
            }
        }
    }
}