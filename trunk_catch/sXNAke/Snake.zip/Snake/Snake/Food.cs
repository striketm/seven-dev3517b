using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Snake
{
    public class Food : DrawableGameComponent
    {
        SpriteBatch sBatch;
        Rectangle spriteRectangle;
        Texture2D texture;
        public Vector2 position;
        Random random;
        public int cost;

        public Food(Game game, ref Texture2D newTexture,
            Rectangle rectangle, int newCost)
            : base(game)
        {
            texture = newTexture;
            position = new Vector2();
            random = new Random();
            cost = newCost;
            spriteRectangle = rectangle;
            sBatch = (SpriteBatch)Game.Services.GetService(typeof(SpriteBatch));
        }

        public override void Draw(GameTime gameTime)
        {
            sBatch.Draw(texture, spriteRectangle.Width * position, spriteRectangle, Color.White);

            base.Draw(gameTime);
        }

        public void PutinNewPosition()
        {
            position = new Vector2(random.Next(Game.GraphicsDevice.Viewport.Width / spriteRectangle.Width),
                random.Next(Game.GraphicsDevice.Viewport.Height / spriteRectangle.Width));
        }

        public void Unvisible()
        {
            position = new Vector2(-1);
        }
    }
}