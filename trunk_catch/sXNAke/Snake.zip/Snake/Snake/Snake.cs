using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Snake
{
    public class Snake : DrawableGameComponent
    {
        protected Queue<Vector2> blockPosition;
        protected Vector2 headBLockPosition;
        protected Vector2 moveVectorDirection;
        protected SpriteBatch sBatch;
        protected Texture2D texture;
        protected Rectangle spriteRectangle;
        protected PlayerIndex playerIndex;

        // Game Stuff
        public bool lunch = false;

        // Screen Area
        protected Rectangle screenBounds;

        public Snake(Game game, ref Texture2D theTexture, PlayerIndex playerID,
            Rectangle rectangle)
            : base(game)
        {
            blockPosition = new Queue<Vector2>();
            texture = theTexture;

            playerIndex = playerID;
            // Get the current spritebatch
            sBatch = (SpriteBatch)
                Game.Services.GetService(typeof(SpriteBatch));

            // Create the source rectangle.
            // This represents where is the sprite picture in surface
            spriteRectangle = rectangle;

            screenBounds = new Rectangle(0, 0, Game.Window.ClientBounds.Width,
                Game.Window.ClientBounds.Height);
        }

        public Vector2 Head
        {
            get { return headBLockPosition; }
        }

        public override void Update(GameTime gameTime)
        {
            // Check for user input
            if (playerIndex == PlayerIndex.One)
            {
                HandlePlayer1KeyBoard();
            }
            else
            {
                HandlePlayer2KeyBoard();
            }
            
            // Change snake's position
            if (!lunch)
                blockPosition.Dequeue();
            blockPosition.Enqueue(headBLockPosition);
            headBLockPosition += moveVectorDirection;

            if (headBLockPosition.X >= screenBounds.Right / spriteRectangle.Width)
                headBLockPosition.X = screenBounds.Left / spriteRectangle.Width;
            if (headBLockPosition.X < screenBounds.Left / spriteRectangle.Width)
                headBLockPosition.X = screenBounds.Right / spriteRectangle.Width - 1;
            if (headBLockPosition.Y >= screenBounds.Bottom / spriteRectangle.Width)
                headBLockPosition.Y = screenBounds.Top / spriteRectangle.Width;
            if (headBLockPosition.Y < screenBounds.Top / spriteRectangle.Width)
                headBLockPosition.Y = screenBounds.Bottom / spriteRectangle.Width - 1;

            base.Update(gameTime);
        }

        /// <summary>
        /// Handle the keys for the player 1 (arrow keys)
        /// </summary>
        private void HandlePlayer1KeyBoard()
        {
            KeyboardState keyboard = Keyboard.GetState();
            if (keyboard.IsKeyDown(Keys.Left))
            {
                if (moveVectorDirection != new Vector2(1, 0))
                    moveVectorDirection = new Vector2(-1, 0);
            }
            else
            {
                if (keyboard.IsKeyDown(Keys.Up))
                {
                    if (moveVectorDirection != new Vector2(0, 1))
                        moveVectorDirection = new Vector2(0, -1);
                }
                else
                {
                    if (keyboard.IsKeyDown(Keys.Right))
                    {
                        if (moveVectorDirection != new Vector2(-1, 0))
                            moveVectorDirection = new Vector2(1, 0);
                    }
                    else
                    {
                        if (keyboard.IsKeyDown(Keys.Down))
                        {
                            if (moveVectorDirection != new Vector2(0, -1))
                                moveVectorDirection = new Vector2(0, 1);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Handle the keys for the player 2 (ASDW)
        /// </summary>
        private void HandlePlayer2KeyBoard()
        {
            KeyboardState keyboard = Keyboard.GetState();
            if (keyboard.IsKeyDown(Keys.A))
            {
                if (moveVectorDirection != new Vector2(1, 0))
                    moveVectorDirection = new Vector2(-1, 0);
            }
            else
            {
                if (keyboard.IsKeyDown(Keys.W))
                {
                    if (moveVectorDirection != new Vector2(0, 1))
                        moveVectorDirection = new Vector2(0, -1);
                }
                else
                {
                    if (keyboard.IsKeyDown(Keys.D))
                    {
                        if (moveVectorDirection != new Vector2(-1, 0))
                            moveVectorDirection = new Vector2(1, 0);
                    }
                    else
                    {
                        if (keyboard.IsKeyDown(Keys.S))
                        {
                            if (moveVectorDirection != new Vector2(0, -1))
                                moveVectorDirection = new Vector2(0, 1);
                        }
                    }
                }
            }
        }

        public override void Draw(GameTime gameTime)
        {
            foreach(Vector2 v in blockPosition)
                sBatch.Draw(texture, spriteRectangle.Width * v, spriteRectangle, Color.White);

            sBatch.Draw(texture, spriteRectangle.Width * headBLockPosition, spriteRectangle, Color.White);

            base.Draw(gameTime);
        }

        public void PutinStartPosition()
        {
            int i = 0;
            // Snake's start position
            blockPosition.Clear();
            if (playerIndex == PlayerIndex.One)
            {
                for (i = 10; i < 14; i++)
                    blockPosition.Enqueue(new Vector2(i, 10));
                headBLockPosition = new Vector2(i, 10);
            }
            else
            {
                for (i = 10; i < 14; i++)
                    blockPosition.Enqueue(new Vector2(i, 15));
                headBLockPosition = new Vector2(i, 15);
            }
            // Move direction is right
            moveVectorDirection = new Vector2(1, 0);
        }

        /// <summary>
        /// Check snake's collision itself
        /// </summary>
        /// <param name="vector">Head of snake</param>
        /// <returns></returns>
        public bool CheckCollision(Vector2 vector)
        {
            return blockPosition.Contains(vector);
        }        
    }
}