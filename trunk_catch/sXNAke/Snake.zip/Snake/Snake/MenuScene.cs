using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;
using Snake.Core;

namespace Snake
{
    /// <summary>
    /// This is a game component that implements the Game Start Scene.
    /// </summary>
    public class MenuScene : GameScene
    {
        // Misc
        protected TextMenuComponent menu;
        // Spritebatch
        protected SpriteBatch spriteBatch = null;
        
        /// <summary>
        /// Default Constructor
        /// </summary>
        /// <param name="game">Main game object</param>
        /// <param name="smallFont">Font for the menu items</param>
        /// <param name="largeFont">Font for the menu selcted item</param>
        /// <param name="background">Texture for background image</param>
        public MenuScene(Game game, SpriteFont smallFont, SpriteFont largeFont,
                            Texture2D background)
            : base(game)
        {
            Components.Add(new ImageComponent(game, background, 
                                            ImageComponent.DrawMode.Center));

            // Create the Menu
            string[] items = {"One Player", "Two Players", "Quit"};
            menu = new TextMenuComponent(game, smallFont, largeFont);
            menu.SetMenuItems(items);
            Components.Add(menu);

            // Get the current spritebatch
            spriteBatch = (SpriteBatch)Game.Services.GetService(typeof(SpriteBatch));
        }

        /// <summary>
        /// Show the start scene
        /// </summary>
        public override void Show()
        {
            // Put the menu centered in screen
            menu.Position = new Vector2(3 * Game.Window.ClientBounds.Width / 4 - menu.Width / 2 - 20, 
                2 * Game.Window.ClientBounds.Height / 3 - menu.Height / 2 - 20);

            menu.Visible = true;
            menu.Enabled = true;

            base.Show();
        }

        /// <summary>
        /// Hide the start scene
        /// </summary>
        public override void Hide()
        {
            MediaPlayer.Stop();
            base.Hide();
        }

        /// <summary>
        /// Gets the selected menu option
        /// </summary>
        public int SelectedMenuIndex
        {
            get { return menu.SelectedIndex; }
        }
    }
}