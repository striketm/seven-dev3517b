using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Net;
using Microsoft.Xna.Framework.Storage;

namespace TexturizandoPontos
{
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;

        /// <summary>
        /// Shader provido pelo XNA.
        /// Reponsavel por renderizar as primitivas
        /// </summary>
        BasicEffect basicEffect;

        Texture2D texture;

        /*Um objeto VertexDeclaration armazena o formato do v�rtice para o 
         * dado contido em cada em cada v�rtice da figura ou modelo. 
         * Antes de desenhar o objeto, o GraphicsDevice precisa ser 
         * modificado para usar o formato correto para permitir a 
         * recupera��o apropriada do dado do v�rtice de cada v�rtice do array.
         * */
        /// <summary>
        /// Armazena o formato do vertice, neste exemplo guardara o formato
        /// do vertice de tipo VertexPositionColor
        /// </summary>
        VertexDeclaration vertexDeclaration;

        VertexPositionTexture[] pointList;

        /// <summary>
        /// Define uma lista de pontos para o array de vertices pointList
        /// </summary>
        void define_Point_List()
        {
            this.pointList = new VertexPositionTexture[25];          

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    this.pointList[(i * 5) + j].Position =
                        new Vector3(100 + (i * 150), 50 + (j * 100), 0);
                }
            }

        }

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        protected override void Initialize()
        {
            this.define_Point_List();

            base.Initialize();

            this.basicEffect = new BasicEffect(this.GraphicsDevice, null);

            this.vertexDeclaration = new VertexDeclaration(
                this.GraphicsDevice, VertexPositionTexture.VertexElements);

            /*Mudando a Origem da tela. O local aonde os eixos se cruzam, etc
             * Antes a origem estava no meio da tela, agora ela est� no canto
             * superior esquerdo da tela do monitor; o padrao usado 
             * no ambiente 2D
             * */
            this.basicEffect.Projection
            = Matrix.CreateOrthographicOffCenter(
                    0, this.GraphicsDevice.Viewport.Width,
                    this.GraphicsDevice.Viewport.Height, 0, 0, 1);

            this.basicEffect.TextureEnabled = true;
            this.basicEffect.Texture = texture;            

            this.graphics.GraphicsDevice.RenderState.PointSpriteEnable = true;
            this.graphics.GraphicsDevice.RenderState.PointSize = 50;
        }

        protected override void LoadContent()
        {
            texture = this.Content.Load<Texture2D>("Mouse");

            base.LoadContent();
        }

        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Black);

            this.GraphicsDevice.VertexDeclaration = this.vertexDeclaration;            

            this.basicEffect.Begin();

            foreach (EffectPass pass in basicEffect.CurrentTechnique.Passes)
            {
                pass.Begin();

                this.GraphicsDevice.DrawUserPrimitives(PrimitiveType.PointList,
                    pointList, 0, 25);

                pass.End();
            }

            this.basicEffect.End();

            base.Draw(gameTime);
        }
    }
}
